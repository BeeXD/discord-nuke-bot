This is a Educational and Experimental Purpose Bot


Made by BeeXD#7777


First install Npm packages 

Discord.js - npm install discord.js

Raid package - npm i discord-raid-toolkit-revamp

------------------------------------------------------------
How to start?

From Discord developer portal ,Make a Application
then go to bot and copy the token

Paste the token in the last line of index.js

and run !!

############
Commands
!channel - make a unlimited channels and pings everyone


!deletechannels - Deletes every channels



###########
DISCLAIMER

-I am not responsible for any grief in your server
-I made this bot for educational purpose
-I will not add any features.

